package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here

        List<String> lines;
        City personal;
        List<City> personals = new LinkedList<>();
        String[] data;
        //file read
  //  try {
  //      System.out.println("!!!");
  //      lines = Files.readAllLines(Paths.get("C:\\Users\\world\\OneDrive\\Рабочий стол\\test\\city_ru.csv"));
  //      for (String s : lines) {
  //          data = s.split(";");
  //          if (data.length == 6) ;
  //          personals.add(new City(data));


  //      }
  //      //sout
  //      for (City str : personals) {
  //          System.out.println(str);
  //      }
  //  } catch (IOException e) {
  //      e.printStackTrace();
  //  }

        File file = new File("C:\\Users\\world\\OneDrive\\Рабочий стол\\test\\city_ru.csv");

        try {

            Scanner sc = new Scanner(file);

            while (sc.hasNextLine()) {

                data = sc.nextLine().split(";");
                if (data.length == 6) ;
                personals.add(new City(data));
            }
            for (City str : personals) {
                System.out.println(str);
            }
            sc.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }


}
